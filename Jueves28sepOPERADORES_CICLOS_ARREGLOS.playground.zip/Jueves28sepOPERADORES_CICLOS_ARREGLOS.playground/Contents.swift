import UIKit

//Ejercicio 1: Con las siguientes variables: let numero1 = 7 let numero2 = 11 Realiza tres operaciones aritmeticas y tres operaciones de comparación.
let numero1 = 7
let numero2 = 11
let suma = numero1 + numero2
let resta = numero2 - numero1
let modulo = numero2 % numero1
let igual = numero1 == numero2
let menor_igual = numero1 <= numero2
let diferente = numero1 != numero2

//Ejercicio 2: Declara un arreglo de enteros con mas de 5 elementos.
var numeritos : [Int] = [5,6,4,3,1,25,18]

//Ejercicio 3: Encuentra el numero de elementos del arreglo.
var tamaño_numeritos = numeritos.count

//Ejercicio 4: Imprime el arreglo ordenado utilizando el metodo sorted()
var numeritos_ordenados = numeritos.sorted()
print(numeritos_ordenados)

//Ejercicio 5: Agrega dos elementos al arreglo
numeritos.append(30)
numeritos.append(20)

//Ejercicio 6: Elimina el tercer elemento del arreglo
numeritos.remove(at:2)
print(numeritos)

//Ejercicio 7: Con las variables: let a = 4 let b = 3 Si 'a' es mas grande que 'b' imprime un mensaje que diga "A es mas grande que B" Utilizando If
let a = 4
let b = 3
if (a>b) 
{
    print("A es mas grande que B")
}

//Ejercicio 8: En una variable declara tu edad y utilizando el operador ternario determina si eres mayor de 21 o no impreso en pantalla
var edad = 18
var compara = edad<21 ? "Menor a 21 años" : "Mayor a 21 años"
print(compara)

//Ejercicio 9: Haz una estructura if, else if, else para cada variable siguiente donde se determine si un numero es positivo, negativo o es cero. let num1 = 3 let num2 = -4
let num1 = 3
let num2 = -4
if (num1==0)
{
    print("El numero es cero")
}
else if (num1<0)
{
    print("El numero es negativo")
}
else
{
    print("El numero es positivo")
}

if (num2==0)
{
    print("El numero es cero")
}
else if (num2<0)
{
    print("El numero es negativo")
}
else
{
    print("El numero es positivo")
}

//Ejercicio 10: Declara la variable let clima = "Soleado" Y crea una estructura switch para para determinar si el clima es agradable con los casos: case "Soleado" -> Es agradable case "Nublado" -> No es agradable case "Lloviendo" -> No es agradable
let clima = "Soleado"
switch(clima)
{
case "soleado":
    print("Es agradable")
case "nublado":
    print("No es agradable")
case "lloviendo":
    print("No es agradable")
default:
    print("No sé")
}
