//ejercicio uno
var i : Int
i = 1
print("Con for:")
print(" ")
for i in 1...10
{
    print(i)
}
print(" ")
print("Con while:")
print(" ")
i = 1
while i < 11
{
    print(i)
    i += 1
}
print(" ")
print("Con repeat:")
i = 1
repeat
{
    print(i)
    i += 1
} while i < 11
print("------------------")
//ejercicio dos
for i in stride(from: 2, to: 21, by:+2)
{
    print(i)
}
/*
var arreglo : [Int] = []
for agregado in 1...10
 */
print("------------------")
//ejercicio cuatro
i = 10
while i > 0
{
    print(i)
    i -= 1
}
print("------------------")
//ejercicio cinco
func nombre()
{
    print("Diana")
}
nombre() //se llama a la función para imprimir su contenido
print("------------------")
//ejercicio seis
func completo(ape: String, nombre: String) -> String //no es necesario poner que regrese algo
{
    let nombresito = "Hola soy \(nombre) \(ape)"
    return nombresito
}
let resultado = completo(ape: "Sanchez", nombre: "Diana")
print(resultado)
print("------------------")
//ejercicio siete
func area(base: Int, altura: Int) -> Int
{
    let trian = base * altura / 2
    return trian
}
let gulo = area(base: 5, altura: 4)
print("El area del triangulo es: \(gulo)")

