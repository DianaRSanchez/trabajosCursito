import UIKit

var saludo = "Hola mundo"
print(saludo)

//Ejercicios
/*1. En un comentario de una linea escribe tu nombre de pila.
 2. En un comentario multilinea escribe tu nombre de pila, tu carrera y tu edad.
 3. Declara una variable de tipo string, booleano y entero y asigna un valor para cada una.
 4. Declara 4 variables sin asignarles un valor.
 5. Declara 4 variables de cualquier tipo y asigna un valor para cada una de ellas.
 6. Declara las variables necesarias para almacenar tu nombre de pila, tu apellido , tu edad diferenciando entre var y let.*/

//Diana
/*
Diana
Matemáticas aplicadas y computación
18 años
*/

let comidaFav: String = "Mi comida favorita son las verdolagas"
let tienePareja: Bool = true
let numMascotas: Int = 3

let base: Double?
let altura: Double?
let numhermanos: Int?
let ciudad: String?

let flor: String = "Gardenias"
let promedio: Double = 8.6
let calificacionRestaurante: Int = 10
let estudiante: Bool = true

let nombre: String = "Diana"
let apellido: String = "Sanchez"
var edad: Int = 18
print("Mi nombre es \(nombre) \(apellido) y tengo \(edad) años")

